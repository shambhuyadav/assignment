<script type="text/javascript">
 $(document).ready(function(){
  $("#cha").click(function(){
    $("#form1").show();
    $("#form2").hide();
    $("#table1").hide();
    $("#ppp").hide();
  });

  $("#fil").click(function(){
    $("#form2").show();
    $("#form1").hide();
    $("#table1").hide();
    $("#ppp").hide();
  });
});
</script>
<script>
$(document).ready(function() {
    $('#butsave').on('click', function() {
      var name = $('#name').val();
      var email = $('#email').val();
      var phone = $('#phone').val();
   
     
      if(name!="" && email!="" && phone!="" ){
        //   $("#butsave").attr("disabled", "disabled");
          $.ajax({
              url: "/",
              type: "POST",
              data: {
                  _token: $("#csrf").val(),
                  type: 1,
                  name: name,
                  email: email,
                  phone: phone
                 
              },
              cache: true,
              success: function(dataResult){
                  console.log(dataResult);
                  var dataResult = JSON.parse(dataResult);
                  if(dataResult.statusCode==200){
                    // window.location = "/";
                    $("#pp").html("Data Insert <b>successfully!</b>");
                    $("#table1").show();
                    $("#form1").hide();
                    $("#form_details1").html("<tr><td>"+name+"</td><td>"+email+"</td><td>"+phone+"</td></tr>");
                    $("#ppp").show();	
                    document.getElementById("name").reset();

                  }
                  else if(dataResult.statusCode==201){
                     alert("Error occured !");
                  }
                  
              }

          });
      }
      else{
          alert('Please fill all the field !');
      }
  });

});
</script>
<script>
$(document).ready(function() {
    $('#butsave1').on('click', function() {
      var f_name = $('#f_name').val();
      var f_details = $('#f_details').val();
      var f_release_date = $('#f_release_date').val();
   
     
      if(f_name!="" && f_details!="" && f_release_date!="" ){
        //   $("#butsave").attr("disabled", "disabled");
          $.ajax({
              url: "/sam",
              type: "POST",
              data: {
                  _token: $("#csrf1").val(),
                  type: 1,
                  f_name: f_name,
                  f_details: f_details,
                  f_release_date: f_release_date
                 
              },
              cache: false,
              success: function(dataResult){
                  console.log(dataResult);
                  var dataResult = JSON.parse(dataResult);
                  if(dataResult.statusCode==200){
                    // window.location = "/";
                    $("#pp").html("Data Insert <b>successfully!</b>");
                    $("#table1").show();
                    $("#form2").hide();
                    $("#form_details1").html("<tr><td>"+f_name+"</td><td>"+f_details+"</td><td>"+f_release_date+"</td></tr>");
                    $("#ppp").show();

                  }
                  else if(dataResult.statusCode==201){
                     alert("Error occured !");
                  }
                  
              }
          });
      }
      else{
          alert('Please fill all the field !');
      }
  });
});
</script>
</body>
</html>