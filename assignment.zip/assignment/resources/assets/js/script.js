
$(document).ready(function(){
  $("#cha").click(function(){
    alert('kkkk');
  });
  // $("#show").click(function(){
  //   $("p").show();
  // });
});