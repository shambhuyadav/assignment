<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class characters extends Model
{    
	protected $table = 'characters';
    protected $fillable = ['name', 'email' , 'phone'];
}
