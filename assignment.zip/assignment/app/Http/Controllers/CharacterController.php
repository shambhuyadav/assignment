<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\characters;

class CharacterController extends Controller
{
  public function index()
    {
        return view('home');
    }  

  public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'email' => 'required',
            'phone' => 'required',
        ]);
        characters::create($request->all());
        return json_encode(array(
        	"statusCode"=>200,
        	"info"=>55
        ));
    } 
}
