<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\films;

class FilmsController extends Controller
{
   public function index()
    {
        return view('home');
    }  

  public function store(Request $request)
    {
        $request->validate([
            'f_name' => 'required',
            'f_details' => 'required',
            'f_release_date' => 'required',
        ]);
        films::create($request->all());
        return json_encode(array(
        	"statusCode"=>200
        
        ));
    } 
}
