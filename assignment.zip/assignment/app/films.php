<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class films extends Model
{
    protected $table = 'films';
    protected $fillable = ['f_name', 'f_details' , 'f_release_date'];
}
